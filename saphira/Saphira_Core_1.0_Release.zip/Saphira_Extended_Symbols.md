Sample content for Saphira_Extended_Symbols.md.
