Sample content for Saphira_Language_Spec_Core1.0.md.
