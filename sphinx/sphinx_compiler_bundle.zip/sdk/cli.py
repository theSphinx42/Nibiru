# cli.py - Entry point for $phinx CLI commands
