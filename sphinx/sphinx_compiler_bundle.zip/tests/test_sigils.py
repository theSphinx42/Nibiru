# Unit test for sigil generation
