# qflags.py - Qubit class and symbolic quantum logic
