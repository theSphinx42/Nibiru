# qbridge.py - Future QPU interface
