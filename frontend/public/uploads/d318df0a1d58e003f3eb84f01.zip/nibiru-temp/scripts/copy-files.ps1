$ErrorActionPreference = 'Stop'
$TARGET_DIR = Join-Path $env:USERPROFILE 'Desktop\nibiru-temp\scripts'

# Create necessary directories
New-Item -ItemType Directory -Force -Path (Join-Path $TARGET_DIR 'app')
New-Item -ItemType Directory -Force -Path (Join-Path $TARGET_DIR 'app\backend')
New-Item -ItemType Directory -Force -Path (Join-Path $TARGET_DIR 'app\frontend')
New-Item -ItemType Directory -Force -Path (Join-Path $TARGET_DIR 'app\backend\media')
New-Item -ItemType Directory -Force -Path (Join-Path $TARGET_DIR 'app\backend\media\avatars')
New-Item -ItemType Directory -Force -Path (Join-Path $TARGET_DIR 'app\backend\media\backgrounds')

# Copy all files
Write-Host 'Copying files...'
Copy-Item -Path '..\app\*' -Destination (Join-Path $TARGET_DIR 'app') -Recurse -Force
Copy-Item -Path '..\scripts\*' -Destination $TARGET_DIR -Recurse -Force
Copy-Item -Path '..\README.md' -Destination $TARGET_DIR -Force
Copy-Item -Path '..\docker-compose.yml' -Destination $TARGET_DIR -Force

Write-Host 'Files copied successfully!'
Write-Host "All project files are now in: $TARGET_DIR" 