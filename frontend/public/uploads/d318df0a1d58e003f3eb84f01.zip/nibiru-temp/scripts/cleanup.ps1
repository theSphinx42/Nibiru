$ErrorActionPreference = 'Stop'

# Define the main user paths
$USER_PROFILE = $env:USERPROFILE
$LOCAL_DESKTOP = Join-Path $USER_PROFILE "Desktop"
$ONEDRIVE_DESKTOP = Join-Path $USER_PROFILE "OneDrive\Desktop"
$BASE_DIR = "C:\Users\angel\Desktop\nibiru-temp"

Write-Host "Starting desktop cleanup and consolidation..."

# Function to consolidate desktop contents
function Consolidate-DesktopFolders {
    Write-Host "Consolidating desktop folders..."
    
    # Ensure the main Desktop folder exists
    if (-not (Test-Path $LOCAL_DESKTOP)) {
        New-Item -ItemType Directory -Force -Path $LOCAL_DESKTOP
    }
    
    # If OneDrive Desktop exists, move its contents to main Desktop
    if (Test-Path $ONEDRIVE_DESKTOP) {
        Write-Host "Found OneDrive Desktop folder. Consolidating contents..."
        
        # Move all items from OneDrive Desktop to main Desktop
        Get-ChildItem -Path $ONEDRIVE_DESKTOP -Force | ForEach-Object {
            $targetPath = Join-Path $LOCAL_DESKTOP $_.Name
            if (-not (Test-Path $targetPath)) {
                Move-Item -Path $_.FullName -Destination $LOCAL_DESKTOP -Force
                Write-Host "Moved $($_.Name) to main Desktop"
            } else {
                Write-Host "Skipped $($_.Name) - already exists in main Desktop"
            }
        }
        
        # Create a backup of OneDrive Desktop before removing
        $backupPath = Join-Path $USER_PROFILE "OneDrive\Desktop_Backup_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
        if (Test-Path $ONEDRIVE_DESKTOP) {
            Write-Host "Creating backup of OneDrive Desktop at: $backupPath"
            Move-Item -Path $ONEDRIVE_DESKTOP -Destination $backupPath -Force
        }
    }
}

# Function to remove duplicate folders
function Remove-DuplicateFolders {
    param (
        [string]$Path
    )
    
    Write-Host "Checking for duplicate folders in: $Path"
    $dirs = Get-ChildItem -Path $Path -Directory -Recurse
    
    foreach ($dir in $dirs) {
        if (-not (Test-Path $dir.FullName)) { continue }
        
        $parentFiles = Get-ChildItem -Path $dir.Parent.FullName -File -ErrorAction SilentlyContinue
        $currentFiles = Get-ChildItem -Path $dir.FullName -File -ErrorAction SilentlyContinue
        
        if ($parentFiles.Count -eq $currentFiles.Count) {
            $isDuplicate = $true
            foreach ($file in $parentFiles) {
                if (-not (Test-Path (Join-Path $dir.FullName $file.Name))) {
                    $isDuplicate = $false
                    break
                }
            }
            
            if ($isDuplicate) {
                Write-Host "Removing duplicate folder: $($dir.FullName)"
                Remove-Item -Path $dir.FullName -Recurse -Force -ErrorAction SilentlyContinue
            }
        }
    }
}

# Function to clean up nibiru-temp project
function Clean-NibiruTemp {
    Write-Host "Cleaning up nibiru-temp project structure..."
    
    # Ensure correct structure
    $correctStructure = @(
        'scripts',
        'app/backend',
        'app/frontend',
        'app/backend/media/avatars',
        'app/backend/media/backgrounds'
    )

    foreach ($path in $correctStructure) {
        $fullPath = Join-Path $BASE_DIR $path
        if (-not (Test-Path $fullPath)) {
            Write-Host "Creating directory: $path"
            New-Item -ItemType Directory -Force -Path $fullPath
        }
    }

    # Move files to correct locations
    $filesToMove = @{
        'README.md' = 'scripts'
        'docker-compose.yml' = 'scripts'
    }

    foreach ($file in $filesToMove.GetEnumerator()) {
        $sourcePath = Join-Path $BASE_DIR $file.Key
        $destPath = Join-Path $BASE_DIR $file.Value $file.Key
        
        if (Test-Path $sourcePath) {
            Write-Host "Moving $($file.Key) to $($file.Value)"
            Move-Item -Path $sourcePath -Destination $destPath -Force
        }
    }
}

# Main execution
Write-Host "Starting cleanup process..."

# Step 1: Consolidate Desktop folders
Consolidate-DesktopFolders

# Step 2: Clean up nibiru-temp project
Clean-NibiruTemp

# Step 3: Remove any remaining duplicates
Remove-DuplicateFolders -Path $LOCAL_DESKTOP

Write-Host "Cleanup completed!"
Write-Host "Your desktop has been consolidated to: $LOCAL_DESKTOP"
Write-Host "A backup of your OneDrive Desktop has been created (if it existed)"
Write-Host "`nFinal nibiru-temp structure:"
Get-ChildItem -Path $BASE_DIR -Recurse -Directory | ForEach-Object {
    $relativePath = $_.FullName.Substring($BASE_DIR.Length + 1)
    Write-Host "  $relativePath"
} 