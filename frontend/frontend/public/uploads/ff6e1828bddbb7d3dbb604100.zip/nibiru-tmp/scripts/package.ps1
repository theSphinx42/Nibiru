$ErrorActionPreference = 'Stop'
$TEMP_DIR = 'nibiru-temp'
$ZIP_NAME = Join-Path $env:USERPROFILE 'OneDrive\Desktop\nibiru.zip'

# Clean up any existing temporary directory or zip
if (Test-Path $TEMP_DIR) { Remove-Item -Recurse -Force $TEMP_DIR }
if (Test-Path $ZIP_NAME) { Remove-Item -Force $ZIP_NAME }

# Create temporary directory
New-Item -ItemType Directory -Force -Path $TEMP_DIR

# Copy project files
Write-Host 'Copying project files...'
Copy-Item -Path 'app','scripts','README.md','docker-compose.yml' -Destination $TEMP_DIR -Recurse -Force

# Create zip file
Write-Host 'Creating zip file...'
Compress-Archive -Path "$TEMP_DIR\*" -DestinationPath $ZIP_NAME -Force

# Clean up
Remove-Item -Recurse -Force $TEMP_DIR

Write-Host 'Package created successfully!'
Write-Host "You can find the zip file at: $ZIP_NAME"
Write-Host ''
Write-Host 'To use the package:'
Write-Host '1. Extract the zip file'
Write-Host '2. Navigate to the extracted directory'
Write-Host '3. Run the appropriate development script:'
Write-Host '   - On Windows: scripts\dev.bat'
Write-Host '   - On Unix: ./scripts/dev.sh' 